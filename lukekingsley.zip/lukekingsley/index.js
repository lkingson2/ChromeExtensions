require('rootpath')();
const logger      = require('logger/logger')('rajpatel.log');
const express     = require('express');
const request     = require('request');
const bodyParser  = require('body-parser');
const querystring = require('querystring')

var router = express.Router();


var client_id = '16626e8a22a14d07b416721db3f0f741'; // Your client id
var client_secret = '8b72e2be730b4632904843e5c8af9109'; // Your secret
var redirect_uri = 'http://lukekingsley.example.com:8080/spotify'; // Your redirect uri
var stateKey = 'spotify_auth_state'; //the state key

var generateRandomString = function(length) {
  var text = '';
  var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

  for (var i = 0; i < length; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
  }
  return text;
};


router.use(express.static(__dirname + '/public'))


router.get('/', function(req, res) {
  res.render(__dirname + '/web/index.pug');
});

router.get('/login', function(req, res) {
  //res.render(__dirname + '/web/login.pug');
  var state = generateRandomString(16);
  res.cookie(stateKey, state);

  // your application requests authorization
  var scope = 'user-read-private user-read-email';
  res.redirect('https://accounts.spotify.com/authorize?' +
    querystring.stringify({
      response_type: 'code',
      client_id: client_id,
      scope: scope,
      redirect_uri: redirect_uri,
      state: state
  }));
});


router.get('/spotify', function(req, res) {
  res.render(__dirname + '/web/spotify.pug')
});


module.exports = router;

